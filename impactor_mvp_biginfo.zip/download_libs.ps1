# download_libs.ps1
# Simple PowerShell helper to download Three.js ESM build and OrbitControls into ./libs/
# Usage: Open PowerShell in this folder and run: .\download_libs.ps1

$ErrorActionPreference = 'Stop'
$libsDir = Join-Path -Path $PSScriptRoot -ChildPath 'libs'
if(-not (Test-Path $libsDir)){
    New-Item -ItemType Directory -Path $libsDir | Out-Null
}

Write-Host "Downloading Three.js ESM module and OrbitControls into: $libsDir"

$files = @(
    @{ url = 'https://unpkg.com/three@0.160.0/build/three.module.js'; out = 'three.module.js' },
    @{ url = 'https://unpkg.com/three@0.160.0/examples/jsm/controls/OrbitControls.js'; out = 'OrbitControls.js' }
)

foreach($f in $files){
    $outPath = Join-Path $libsDir $f.out
    Write-Host "Fetching $($f.url) -> $outPath"
    try{
        Invoke-WebRequest -Uri $f.url -OutFile $outPath -UseBasicParsing -ErrorAction Stop
        Write-Host "Saved $outPath"
    } catch {
        Write-Host "Failed to download $($f.url): $_" -ForegroundColor Yellow
    }
}

# Post-processing: make OrbitControls import the local three.module.js instead of bare 'three'
$orbitPath = Join-Path $libsDir 'OrbitControls.js'
if(Test-Path $orbitPath){
    try{
        $txt = Get-Content -Raw -Path $orbitPath -ErrorAction Stop
        # Replace both single-quoted and double-quoted imports of 'three'
        $new = $txt -replace "from\s+'three'","from './three.module.js'"
        $new = $new -replace 'from\s+"three"',"from './three.module.js'"
        if($new -ne $txt){
            Set-Content -Path $orbitPath -Value $new -Force
            Write-Host "Patched OrbitControls.js to use local three.module.js imports"
        }
    } catch{
        Write-Host "Warning: failed to patch OrbitControls.js: $_" -ForegroundColor Yellow
    }
}

Write-Host "Done. If you open three.html from a local server (eg. python -m http.server) the page will prefer the local libs/ files." -ForegroundColor Green
