window.IMPACTOR_CFG = {
  apiBase: "http://127.0.0.1:8000",
  maptiler: {
    style: "streets-v2",
    key: "p1QzpElLiaTspA4CPIit"   // <--- tu key
  },
  geocoding: {
    provider: "opencage",
    key: "154fc0176b684e82bdb2c6c072fd4d17"
  }
};
