// Production configuration overrides for Impactor frontend
// Fill with your public backend URL and API keys.
// This file is safe to commit if keys are intended for client-side use.

window.IMPACTOR_CFG_PROD = {
  // Public backend base URL (Render/Railway/Fly.io)
  apiBase: "https://your-backend.example.com",

  // MapTiler style and key used by Leaflet tiles
  maptiler: {
    style: "streets-v2",
    key: "YOUR_MAPTILER_KEY"
  },

  // Geocoding provider and key (OpenCage)
  geocoding: {
    provider: "opencage",
    key: "YOUR_OPENCAGE_KEY"
  }
};