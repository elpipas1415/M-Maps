from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
import math
import requests
from typing import Optional

"""
This module implements the backend for the Impactor MVP educational simulator.

The API exposes a single POST endpoint at `/simulate` that accepts
parameters describing a hypothetical asteroid impact and returns
physical calculations (mass, energy, crater size) as well as
educational advice on evacuation, deflection strategies and
communication plans. It is intentionally simplified for clarity and
learning; it is not a prediction engine.

The endpoint accepts additional fields such as lead_time_years,
composition, rotation_period_h and impact_probability, which are
used to compute recommendations and warnings.

Usage:
    uvicorn main:app --reload
then POST a JSON payload to /simulate. See README.md for more details.
"""

app = FastAPI(title="Impactor MVP API",
              description="Educational impact simulation API (MVP+educational)",
              version="0.2.0")

# Enable CORS for all origins. This is useful for local development; in
# production you should restrict origins as appropriate.
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# ----------------------------- Models -----------------------------
class SimInput(BaseModel):
    """Parameters required to simulate an impact scenario."""
    diameter_m: float = Field(..., gt=0, description="Asteroid diameter in meters")
    density_kg_m3: float = Field(..., gt=0, description="Density in kg/m³")
    velocity_m_s: float = Field(..., gt=0, description="Relative velocity in m/s")
    impact_angle_deg: float = Field(45, ge=0, le=90, description="Impact angle in degrees")
    lat: float = Field(..., ge=-90, le=90, description="Latitude of impact point")
    lon: float = Field(..., ge=-180, le=180, description="Longitude of impact point")
    # Additional educational parameters
    lead_time_years: float = Field(1.0, ge=0.0, description="Years until potential impact")
    dv_mm_s: float = Field(1.0, ge=0.0, description="Available delta-v (mm/s)")
    composition: str = Field("rocky", description="Composition: rocky | metallic | porous")
    rotation_period_h: float = Field(8.0, ge=0.0, description="Rotation period in hours")
    impact_probability: float = Field(1.0, ge=0.0, le=1.0, description="Impact probability (0–1)")


class DefenseAdvice(BaseModel):
    category_size: str
    risk_level: str
    evacuation_radius_km: float
    deflection_displacement_km: float
    deflection_target_km: float
    deflection_feasibility: str
    # Names of recommended mitigation/deflection tools
    recommended_tools: list[str]
    # Detailed explanations for each recommended tool.  Each element
    # corresponds to the same index in ``recommended_tools`` and
    # describes how the method works and when it should be used.
    tools_detail: list[str]
    why: str


class AlertsAdvice(BaseModel):
    now: list[str]
    week: list[str]
    months: list[str]
    education: list[str]


class CriticalNotes(BaseModel):
    size: str
    mass_density: str
    velocity: str
    orbit: str
    warning_time: str
    composition_structure: str
    rotation: str
    impact_probability: str


class SimOutput(BaseModel):
    mass_kg: float
    energy_j: float
    energy_tnt_megatons: float
    crater_diameter_m: float
    impact_point: dict
    biome_label: str
    assumptions: dict
    uncertainty: dict
    notes: str
    defense: DefenseAdvice
    alerts: AlertsAdvice
    critical: CriticalNotes

    # Additional educational fields
    earthquake_magnitude: float = Field(..., description="Estimated earthquake magnitude (Richter scale)")
    earthquake_category: str = Field(..., description="Qualitative description of the earthquake magnitude")
    tsunami_risk: str = Field(..., description="Tsunami risk level associated with the impact")

    # Educational description of meteorite type for general understanding.
    meteor_description: str = Field(..., description="Educational description of meteor type (rocky, metallic or porous)")


# ---------------------- Scientific calculations ----------------------
def compute_biome(lat: float) -> str:
    """Return a simplistic biome label based on latitude.

    This is intentionally coarse and meant for educational use only.
    """
    alat = abs(lat)
    if alat < 15:
        return "Tropical (simplified)"
    elif alat < 30:
        return "Subtropical/Desert (simplified)"
    elif alat < 50:
        return "Temperate (simplified)"
    elif alat < 70:
        return "Boreal/Taiga (simplified)"
    else:
        return "Tundra/Polar (simplified)"


def simulate(diameter_m: float, density_kg_m3: float, velocity_m_s: float):
    """Compute mass, kinetic energy and crater diameter for a spherical asteroid.

    Parameters
    ----------
    diameter_m : float
        Diámetro en metros.
    density_kg_m3 : float
        Densidad en kg/m³.
    velocity_m_s : float
        Velocidad relativa en m/s.

    Returns
    -------
    tuple
        (mass_kg, energy_j, energy_mt, crater_diameter_m)
    """
    r = diameter_m / 2.0
    V = (4.0 / 3.0) * math.pi * r ** 3
    m = density_kg_m3 * V
    E = 0.5 * m * velocity_m_s ** 2
    # Convert to megatons TNT (1 ton TNT = 4.184e9 J)
    E_tnt_megatons = (E / 4.184e9) / 1e6
    # Empirical crater diameter approximation (scaling law)
    k = 0.07
    crater_diameter_m = k * (E ** (1.0 / 3.4))
    return m, E, E_tnt_megatons, crater_diameter_m


def uncertainty_range(diameter_m: float, density_kg_m3: float, velocity_m_s: float,
                      rho_pct: float = 0.2, v_pct: float = 0.1):
    """Compute an uncertainty interval for energy and crater size.

    The density and velocity are varied up and down by the given
    percentages to estimate min/max values.
    """
    rho_min = density_kg_m3 * (1 - rho_pct)
    rho_max = density_kg_m3 * (1 + rho_pct)
    v_min = velocity_m_s * (1 - v_pct)
    v_max = velocity_m_s * (1 + v_pct)

    def _calc(rho, v):
        _, E, Emt, Dcr = simulate(diameter_m, rho, v)
        return E, Emt, Dcr

    Emin, Emt_min, Dcr_min = _calc(rho_min, v_min)
    Emax, Emt_max, Dcr_max = _calc(rho_max, v_max)
    return {
        "density_pct": rho_pct * 100,
        "velocity_pct": v_pct * 100,
        "energy_j_min": Emin,
        "energy_j_max": Emax,
        "energy_mt_min": Emt_min,
        "energy_mt_max": Emt_max,
        "crater_diameter_m_min": Dcr_min,
        "crater_diameter_m_max": Dcr_max,
    }


# ---------------------- Educational logic ----------------------
def size_category(d_m: float) -> str:
    """Classify the asteroid size into qualitative bins."""
    if d_m < 10:
        return "very small (meters) — likely disintegrates"
    if d_m < 100:
        return "medium (tens of m) — local/severe damage"
    if d_m < 1000:
        return "large (hundreds of m) — regional/continental"
    return "giant (kilometers) — global threat"


def risk_level(d_m: float, p: float) -> str:
    """Estimate a qualitative risk level from diameter and impact probability."""
    score = (d_m / 50.0) * (p * 10)
    if score < 2:
        return "Low"
    if score < 5:
        return "Moderate"
    if score < 10:
        return "High"
    return "Extreme"


def evacuation_radius_km(crater_d_m: float) -> float:
    """Compute a recommended evacuation radius.

    A simple rule: 3× the crater radius, but not less than 10 km.
    """
    return max(10.0, (crater_d_m / 1000.0) * 1.5) * 2


def defense_recommendations(d_m: float, lead_years: float, composition: str) -> tuple[list[str], list[str]]:
    """
    Generate a list of recommended mitigation/deflection tools *and*
    a corresponding list of detailed explanations for each tool.

    This advice is simplified and meant for educational purposes.  The
    two returned lists have the same length and index alignment.

    Returns
    -------
    tuple(list[str], list[str])
        A tuple where the first element is the list of tool names and
        the second element is the list of descriptions.
    """
    names: list[str] = []
    details: list[str] = []
    # Helper to add a tool and its description together
    def add_tool(name: str, desc: str):
        names.append(name)
        details.append(desc)
    # Kinetic impactor
    if lead_years >= 5:
        add_tool(
            "Kinetic impactor",
            "A spacecraft or projectile strikes the asteroid at high speed to change its trajectory."
            " Effective with years of lead time and for small to medium objects."
        )
        if d_m >= 300:
            add_tool(
                "Gravity tractor",
                "A massive spacecraft parks near the asteroid and uses gravity as a tow to shift it."
                " Requires decades and is expensive, but allows precise deflections."
            )
    elif 1 <= lead_years < 5:
        add_tool(
            "Kinetic impactor",
            "A crash mission is still viable but the time window is limited."
        )
        if d_m >= 500:
            add_tool(
                "Stand-off nuclear deflection",
                "Detonation of a nuclear device at some distance to push the asteroid via radiation pressure."
                " Considered last resort and requires international coordination."
            )
    else:  # menos de 1 año
        add_tool(
            "Civil protection and evacuation plan",
            "When there isn't enough time to deflect the asteroid, prepare evacuation routes, shelters,"
            " and water/food supplies for the affected population."
        )
        if d_m >= 200:
            add_tool(
                "Close-proximity nuclear burst",
                "Detonation of a nuclear device near the asteroid to push it."
                " May create secondary fragments and must be evaluated carefully."
            )
    # Composition-specific advice
    if composition == "porous":
        add_tool(
            "Porous object",
            "Porous or icy objects fragment easily."
            " Prefer gentle pushes and avoid explosions that pulverize them."
        )
    elif composition == "metallic":
        add_tool(
            "Metallic object",
            "Metallic (iron–nickel) asteroids are very dense and resistant."
            " They require higher Δv or a more energetic impact to deflect."
        )
    return names, details


def deflection_feasibility(dv_mm_s: float, lead_years: float) -> tuple[float, float, str]:
    """Estimate the possible displacement given Δv and lead time.

    It returns the displacement in km, a target displacement (e.g., to miss Earth)
    and a feasibility statement.
    """
    dv_m_s = dv_mm_s / 1000.0
    seconds = lead_years * 365.25 * 86400
    disp_km = dv_m_s * seconds / 1000.0
    target_km = 10000.0  # Approximate distance to avert impact
    feas = "Feasible" if disp_km >= target_km else "Insufficient (needs more Δv or more time)"
    return disp_km, target_km, feas

# ------------------------------------------------------------------
#  Earthquake and tsunami estimations

def earthquake_magnitude(energy_j: float) -> tuple[float, str]:
    """Estimate an earthquake magnitude from impact energy.

    Uses a simplified Gutenberg–Richter relationship with
    seismic efficiency of 1e-4 as described in planetary impact
    literature【990159871311599†L159-L172】.

    Parameters
    ----------
    energy_j : float
        Impact energy in Joules.

    Returns
    -------
    tuple (float, str)
        The estimated Richter magnitude and a qualitative category.
    """
    # Compute magnitude using M = 0.67 * log10(E) - 5.87
    # Add small epsilon to avoid log10(0)
    import math
    if energy_j <= 0:
        return (0.0, "No shaking")
    M = 0.67 * (math.log10(energy_j)) - 5.87
    # Categorize qualitatively
    if M < 3.5:
        category = "Micro: barely perceptible"
    elif M < 5.0:
        category = "Light: noticeable, no damage"
    elif M < 6.0:
        category = "Moderate: some local damage"
    elif M < 7.0:
        category = "Strong: regional damage"
    elif M < 8.0:
        category = "Major: severe damage"
    else:
        category = "Catastrophic: extreme destruction"
    return (round(M, 2), category)


def tsunami_risk(energy_mt: float, impact_lat: float) -> str:
    """Estimate a qualitative tsunami risk from energy and latitude.

    This simplified function uses impact energy in megatons and
    latitude to determine if the location is likely near a coast.
    Tsunami hazard from asteroid impacts is a complex topic; a
    NASA/NOAA workshop concluded tsunamis are less threatening than
    previously believed and are significant only for near-shore
    impacts【150808278287727†L15-L24】【150808278287727†L90-L99】. We use a heuristic
    classification:

    - <0.1 Mt: sin riesgo.
    - 0.1–10 Mt: riesgo bajo.
    - 10–100 Mt: riesgo moderado si está en zona costera.
    - >100 Mt: riesgo alto si está en zona costera.

    Returns
    -------
    str
        A descriptive string summarizing the tsunami hazard.
    """
    # Determine coastal proximity: assume latitudes within ±5° of 0 are
    # tropical oceans; this is very coarse. In practice, require
    # external bathymetry data. Here we simply classify latitudes
    # beyond ±60° as unlikely to be oceanic (polar landmasses).
    near_coast = abs(impact_lat) < 50  # simple guess: mid/low latitudes more likely to have coast
    # Classify energy
    if energy_mt < 0.1:
        return "No tsunami risk"
    elif energy_mt < 10:
        return "Low tsunami risk" + (" (coast)" if near_coast else ".")
    elif energy_mt < 100:
        return "Moderate tsunami risk" + (" (coast)" if near_coast else ".")
    else:
        return "High tsunami risk" + (" (coast)" if near_coast else ".")

def meteor_description(composition: str) -> str:
    """Return a human-friendly description of the asteroid type.

    Parameters
    ----------
    composition : str
        One of "rocky", "metallic", or "porous".

    Returns
    -------
    str
        A textual description that summarises typical composition,
        density and examples for the specified category.  If the
        composition is not recognised, a generic message is returned.
    """
    comp = composition.lower()
    if comp == "rocky":
        return (
            "Rocky asteroid (S/C type): mainly composed of silicates, clays and "
            "iron- and magnesium-rich minerals. They are the most common; "
            "typical density is around 2,000–3,500 kg/m³."
        )
    elif comp == "metallic":
        return (
            "Metallic asteroid (M type): mostly iron and nickel, "
            "with shiny surfaces and high density (~7,000–8,000 kg/m³). Less common, "
            "believed to be exposed cores of differentiated asteroids."
        )
    elif comp == "porous":
        return (
            "Porous/cometary asteroid: mixture of rocks and ices (water, CO₂, methane) with "
            "many internal voids. Low density (1,000–2,000 kg/m³) and "
            "easily fragments on atmospheric entry."
        )
    else:
        return (
            "Unrecognized asteroid type. For educational purposes, select 'rocky', "
            "'metallic' or 'porous' to see a specific description."
        )


def alerts_pack(risk: str, evac_km: float,
                biome: str,
                magnitude_category: str,
                tsunami_risk: str) -> AlertsAdvice:
    """Build a collection of alert messages based on risk level, biome and hazards.

    The lists returned (now, week, months, education) are tailored to
    the qualitative risk (`risk`), the biome (e.g., tropical, boreal),
    the earthquake magnitude category, and the tsunami risk.  They
    serve as guidelines for educational purposes and do not
    substitute official emergency planning.
    """
    # Base messages
    now = [
        "Do not look at flashes; stay away from windows.",
        "Follow official civil protection channels."
    ]
    week = [
        "Prepare a 72-hour kit (water, food, flashlight, first aid).",
        f"Family meet-up plan and evacuation routes (~{int(evac_km)} km)."
    ]
    months = [
        "Drills in schools/communities.",
        "Identify nearby hospitals, shelters and evacuation routes."
    ]
    education = [
        "Distinguish this educational scenario from any real official alert.",
        "Understand energy (J/Mt TNT) and why small early Δv is key.",
        "Learn safe routes considering local tsunami, earthquake and wildfire risks."
    ]
    # Adjust for high global risk levels
    if risk in ("High", "Extreme"):
        now.append("Authorities: activate emergency communications (sirens and cell broadcast).")
    # Messages based on earthquake magnitude
    if magnitude_category.startswith("Strong") or magnitude_category.startswith("Major") or magnitude_category.startswith("Catastrophic"):
        now.append("Possible aftershocks: stay in safe areas away from damaged structures.")
    elif magnitude_category.startswith("Moderate"):
        week.append("Inspect and secure vulnerable structures against moderate earthquakes.")
    # Messages based on tsunami risk
    if "High tsunami risk" in tsunami_risk or "Moderate tsunami risk" in tsunami_risk:
        now.append("Evacuate to high ground away from the sea due to tsunami risk.")
        week.append("Plan evacuation routes to elevated areas (10 km inland or more).")
    elif "Low tsunami risk" in tsunami_risk:
        week.append("Monitor coastal alerts; low tsunami risk.")
    # Messages based on biome
    b = biome.lower().split()[0]  # First word (tropical, subtropical/desert, temperate, boreal/taiga, tundra/polar)
    if "tropical" in b:
        week.append("Prepare shelters against heavy rains and landslides.")
        months.append("Identify flood-prone areas and reinforce drainage.")
    elif "subtropical" in b or "desert" in b:
        week.append("Shelter from dust storms and extreme heat; prepare extra water.")
        months.append("Plan firebreaks and avoid accumulation of dry vegetation.")
    elif "temperate" in b:
        week.append("Wildfires may occur; clear dry brush and maintain extinguishers.")
    elif "boreal" in b or "taiga" in b:
        week.append("Risk of fires and strong winds; reinforce structures and maintain water reserves.")
    elif "tundra" in b or "polar" in b:
        week.append("Ensure shelter and heating supplies for extreme cold conditions.")
        months.append("Reinforce shelters against cold and plan evacuation routes over ice.")
    return AlertsAdvice(now=now, week=week, months=months, education=education)


def critical_notes(d: float, rho: float, v: float, lead: float,
                   comp: str, rot_h: float, p: float) -> CriticalNotes:
    """Compose explanatory notes about why each parameter matters."""
    return CriticalNotes(
        size=("If it measures meters → may disintegrate; tens/hundreds of meters → local/regional damage; "
              "kilometers → global threat."),
        mass_density=(f"Mass = ρ·V. With ρ={rho:.0f} kg/m³ the energy and defense choice change greatly."),
        velocity=("More velocity = more energy (E ∝ v²). Affects crater and tsunami."),
        orbit=("Orbit/angle determine entry point; with known orbit the time window can be estimated."),
        warning_time=(f"Available time ≈ {lead:.2f} years: with decades, gentle pushes work; "
                      "with months, only extreme measures/evacuation."),
        composition_structure=("Rocky/Metallic/Porous change strength and whether to push, heat or fragment."),
        rotation=(f"Rotation ~{rot_h:.1f} h: fast/irregular rotation complicates docking or using a gravity tractor."),
        impact_probability=(f"Impact probability = {p:.2f} (educational). Always verify with official sources.")
    )


# ------------------------ API endpoints ------------------------
@app.get("/health")
def health():
    """Simple health check endpoint."""
    return {"status": "ok"}


@app.post("/simulate", response_model=SimOutput)
def simulate_endpoint(payload: SimInput):
    """
    Compute the impact scenario and return educational advice.

    This function combines physical calculations with additional
    educational annotations. It derives the mass, energy and crater
    size of an asteroid impact, estimates an equivalent earthquake
    magnitude and tsunami risk, constructs tailored alerts based on
    biome and hazard severity, and suggests mitigation strategies with
    detailed explanations. The result is packaged into a SimOutput
    object for the frontend to display.
    """
    # Core physical computations
    m, E, Emt, Dcr = simulate(payload.diameter_m,
                              payload.density_kg_m3,
                              payload.velocity_m_s)
    # Determine biome and uncertainty ranges
    biome = compute_biome(payload.lat)
    unc = uncertainty_range(payload.diameter_m,
                            payload.density_kg_m3,
                            payload.velocity_m_s)
    # Classify size and risk
    cat = size_category(payload.diameter_m)
    risk = risk_level(payload.diameter_m, payload.impact_probability)
    # Evacuation and deflection calculations
    evac_km = evacuation_radius_km(Dcr)
    disp_km, target_km, feas = deflection_feasibility(payload.dv_mm_s,
                                                      payload.lead_time_years)
    # Get mitigation tools and detailed descriptions
    tool_names, tool_details = defense_recommendations(
        payload.diameter_m, payload.lead_time_years, payload.composition)
    # Seismic and tsunami estimations
    M, M_cat = earthquake_magnitude(E)
    tsunami = tsunami_risk(Emt, payload.lat)
    # Tailored alerts based on biome, magnitude and tsunami risk
    alerts = alerts_pack(risk, evac_km, biome, M_cat, tsunami)
    # Critical explanatory notes
    crit = critical_notes(payload.diameter_m,
                          payload.density_kg_m3,
                          payload.velocity_m_s,
                          payload.lead_time_years,
                          payload.composition,
                          payload.rotation_period_h,
                          payload.impact_probability)
    # Build defense advice including detailed descriptions
    defense = DefenseAdvice(
        category_size=cat,
        risk_level=risk,
        evacuation_radius_km=round(evac_km, 1),
        deflection_displacement_km=round(disp_km, 1),
        deflection_target_km=target_km,
        deflection_feasibility=feas,
        recommended_tools=tool_names,
        tools_detail=tool_details,
        why="Selection based on size, composition and available time (educational rules)."
    )
    # Compose final output, including educational fields
    return SimOutput(
        mass_kg=m,
        energy_j=E,
        energy_tnt_megatons=Emt,
        crater_diameter_m=Dcr,
        impact_point={"lat": payload.lat, "lon": payload.lon},
        biome_label=biome,
        assumptions={
            "shape": "sphere",
            "density_kg_m3": payload.density_kg_m3,
            "velocity_m_s": payload.velocity_m_s,
            "k_crater": 0.07,
            "model_note": "Simplified model; ignores atmosphere, angle and fragmentation",
        },
        uncertainty=unc,
        notes=(
            "Educational and hypothetical scenario. Approximate results based on simplified models. "
            "This is not a real prediction nor an official warning."
        ),
        defense=defense,
        alerts=alerts,
        critical=crit,
        earthquake_magnitude=M,
        earthquake_category=M_cat,
        tsunami_risk=tsunami,
        meteor_description=meteor_description(payload.composition)
    )

# ------------------------ NASA NEO API integration ------------------------
@app.get("/neo/{asteroid_id}")
def neo_lookup(asteroid_id: int, api_key: str = "t55BCCfA6xPFbfZriD1oakjiEVHqn5dldsXEcAkC"):
    """Look up details about a specific near-Earth object via NASA's NeoWs API.

    This endpoint fetches information from NASA's open NEO service using
    the supplied asteroid ID and API key. If the request fails (e.g., due
    to network issues), it returns a simple error message. See
    https://api.nasa.gov/ for more details on available fields【719571455677715†L208-L214】.

    Parameters
    ----------
    asteroid_id : int
        The NEO's unique identifier.
    api_key : str
        Your NASA API key. Defaults to DEMO_KEY (limited to 30 requests/hr).

    Returns
    -------
    dict
        The JSON response from NASA's API or an error message.
    """
    url = f"https://api.nasa.gov/neo/rest/v1/neo/{asteroid_id}?api_key={api_key}"
    try:
        resp = requests.get(url, timeout=10)
        resp.raise_for_status()
        return resp.json()
    except Exception as e:
        return {"error": str(e)}


@app.get("/neo_feed")
def neo_feed(start_date: str, end_date: Optional[str] = None, api_key: str = "DEMO_KEY"):
    """Retrieve a list of NEOs approaching Earth within a date range.

    This endpoint queries NASA's NeoWs 'feed' endpoint, which returns
    objects with close approach data between start_date and end_date.
    Dates must be in YYYY-MM-DD format. If end_date is not supplied, it
    defaults to start_date. Limits: 7 days per request.

    Parameters
    ----------
    start_date : str
        Start date (YYYY-MM-DD).
    end_date : str, optional
        End date (YYYY-MM-DD). If omitted, uses start_date.
    api_key : str
        NASA API key (DEMO_KEY by default).

    Returns
    -------
    dict
        The JSON response from NASA's API or an error message.
    """
    if end_date is None:
        end_date = start_date
    url = f"https://api.nasa.gov/neo/rest/v1/feed?start_date={start_date}&end_date={end_date}&api_key={api_key}"
    try:
        resp = requests.get(url, timeout=10)
        resp.raise_for_status()
        return resp.json()
    except Exception as e:
        return {"error": str(e)}